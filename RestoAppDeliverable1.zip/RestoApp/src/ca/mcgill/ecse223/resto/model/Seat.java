package ca.mcgill.ecse223.resto.model;

/*PLEASE DO NOT EDIT THIS CODE*/
/*This code was generated using the UMPLE 1.20.1.4071 modeling language!*/



// line 45 "RestoAppDomailModel.ump"
public class Seat
{

  //------------------------
  // MEMBER VARIABLES
  //------------------------

  //Seat Attributes
  private int seatNumber;

  //Seat Associations
  private Table table;
  private Customer customer;

  //------------------------
  // CONSTRUCTOR
  //------------------------

  public Seat(int aSeatNumber, Table aTable, Customer aCustomer)
  {
    seatNumber = aSeatNumber;
    boolean didAddTable = setTable(aTable);
    if (!didAddTable)
    {
      throw new RuntimeException("Unable to create seat due to table");
    }
    boolean didAddCustomer = setCustomer(aCustomer);
    if (!didAddCustomer)
    {
      throw new RuntimeException("Unable to create seat due to customer");
    }
  }

  //------------------------
  // INTERFACE
  //------------------------

  public boolean setSeatNumber(int aSeatNumber)
  {
    boolean wasSet = false;
    seatNumber = aSeatNumber;
    wasSet = true;
    return wasSet;
  }

  public int getSeatNumber()
  {
    return seatNumber;
  }

  public Table getTable()
  {
    return table;
  }

  public Customer getCustomer()
  {
    return customer;
  }

  public boolean setTable(Table aTable)
  {
    boolean wasSet = false;
    //Must provide table to seat
    if (aTable == null)
    {
      return wasSet;
    }

    if (table != null && table.numberOfSeats() <= Table.minimumNumberOfSeats())
    {
      return wasSet;
    }

    Table existingTable = table;
    table = aTable;
    if (existingTable != null && !existingTable.equals(aTable))
    {
      boolean didRemove = existingTable.removeSeat(this);
      if (!didRemove)
      {
        table = existingTable;
        return wasSet;
      }
    }
    table.addSeat(this);
    wasSet = true;
    return wasSet;
  }

  public boolean setCustomer(Customer aNewCustomer)
  {
    boolean wasSet = false;
    if (aNewCustomer == null)
    {
      //Unable to setCustomer to null, as seat must always be associated to a customer
      return wasSet;
    }
    
    Seat existingSeat = aNewCustomer.getSeat();
    if (existingSeat != null && !equals(existingSeat))
    {
      //Unable to setCustomer, the current customer already has a seat, which would be orphaned if it were re-assigned
      return wasSet;
    }
    
    Customer anOldCustomer = customer;
    customer = aNewCustomer;
    customer.setSeat(this);

    if (anOldCustomer != null)
    {
      anOldCustomer.setSeat(null);
    }
    wasSet = true;
    return wasSet;
  }

  public void delete()
  {
    Table placeholderTable = table;
    this.table = null;
    placeholderTable.removeSeat(this);
    Customer existingCustomer = customer;
    customer = null;
    if (existingCustomer != null)
    {
      existingCustomer.setSeat(null);
    }
  }


  public String toString()
  {
	  String outputString = "";
    return super.toString() + "["+
            "seatNumber" + ":" + getSeatNumber()+ "]" + System.getProperties().getProperty("line.separator") +
            "  " + "table = "+(getTable()!=null?Integer.toHexString(System.identityHashCode(getTable())):"null") + System.getProperties().getProperty("line.separator") +
            "  " + "customer = "+(getCustomer()!=null?Integer.toHexString(System.identityHashCode(getCustomer())):"null")
     + outputString;
  }
}