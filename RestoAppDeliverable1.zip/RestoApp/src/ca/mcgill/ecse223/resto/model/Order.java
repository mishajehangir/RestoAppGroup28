package ca.mcgill.ecse223.resto.model;
/*PLEASE DO NOT EDIT THIS CODE*/
/*This code was generated using the UMPLE 1.20.1.4071 modeling language!*/


import java.util.*;

// line 51 "RestoAppDomailModel.ump"
public class Order
{

  //------------------------
  // MEMBER VARIABLES
  //------------------------

  //Order Attributes
  private int orderNumber;

  //Order Associations
  private Waiter waiter;
  private Customer customer;
  private List<Item> items;
  private Bill bill;

  //------------------------
  // CONSTRUCTOR
  //------------------------

  public Order(int aOrderNumber, Waiter aWaiter, Customer aCustomer, Bill aBill, Item... allItems)
  {
    orderNumber = aOrderNumber;
    boolean didAddWaiter = setWaiter(aWaiter);
    if (!didAddWaiter)
    {
      throw new RuntimeException("Unable to create order due to waiter");
    }
    if (aCustomer == null || aCustomer.getOrder() != null)
    {
      throw new RuntimeException("Unable to create Order due to aCustomer");
    }
    customer = aCustomer;
    items = new ArrayList<Item>();
    boolean didAddItems = setItems(allItems);
    if (!didAddItems)
    {
      throw new RuntimeException("Unable to create Order, must have at least 1 items");
    }
    boolean didAddBill = setBill(aBill);
    if (!didAddBill)
    {
      throw new RuntimeException("Unable to create order due to bill");
    }
  }

  public Order(int aOrderNumber, Waiter aWaiter, Bill aBill, Item... allItems)
  {
    orderNumber = aOrderNumber;
    boolean didAddWaiter = setWaiter(aWaiter);
    if (!didAddWaiter)
    {
      throw new RuntimeException("Unable to create order due to waiter");
    }
    customer = new Customer(this);
    items = new ArrayList<Item>();
    boolean didAddItems = setItems(allItems);
    if (!didAddItems)
    {
      throw new RuntimeException("Unable to create Order, must have at least 1 items");
    }
    boolean didAddBill = setBill(aBill);
    if (!didAddBill)
    {
      throw new RuntimeException("Unable to create order due to bill");
    }
  }

  //------------------------
  // INTERFACE
  //------------------------

  public boolean setOrderNumber(int aOrderNumber)
  {
    boolean wasSet = false;
    orderNumber = aOrderNumber;
    wasSet = true;
    return wasSet;
  }

  public int getOrderNumber()
  {
    return orderNumber;
  }

  public Waiter getWaiter()
  {
    return waiter;
  }

  public Customer getCustomer()
  {
    return customer;
  }

  public Item getItem(int index)
  {
    Item aItem = items.get(index);
    return aItem;
  }

  public List<Item> getItems()
  {
    List<Item> newItems = Collections.unmodifiableList(items);
    return newItems;
  }

  public int numberOfItems()
  {
    int number = items.size();
    return number;
  }

  public boolean hasItems()
  {
    boolean has = items.size() > 0;
    return has;
  }

  public int indexOfItem(Item aItem)
  {
    int index = items.indexOf(aItem);
    return index;
  }

  public Bill getBill()
  {
    return bill;
  }

  public boolean setWaiter(Waiter aWaiter)
  {
    boolean wasSet = false;
    if (aWaiter == null)
    {
      return wasSet;
    }

    Waiter existingWaiter = waiter;
    waiter = aWaiter;
    if (existingWaiter != null && !existingWaiter.equals(aWaiter))
    {
      existingWaiter.removeOrder(this);
    }
    waiter.addOrder(this);
    wasSet = true;
    return wasSet;
  }

  public boolean isNumberOfItemsValid()
  {
    boolean isValid = numberOfItems() >= minimumNumberOfItems();
    return isValid;
  }

  public static int minimumNumberOfItems()
  {
    return 1;
  }

  public boolean addItem(Item aItem)
  {
    boolean wasAdded = false;
    if (items.contains(aItem)) { return false; }
    items.add(aItem);
    if (aItem.indexOfOrder(this) != -1)
    {
      wasAdded = true;
    }
    else
    {
      wasAdded = aItem.addOrder(this);
      if (!wasAdded)
      {
        items.remove(aItem);
      }
    }
    return wasAdded;
  }

  public boolean removeItem(Item aItem)
  {
    boolean wasRemoved = false;
    if (!items.contains(aItem))
    {
      return wasRemoved;
    }

    if (numberOfItems() <= minimumNumberOfItems())
    {
      return wasRemoved;
    }

    int oldIndex = items.indexOf(aItem);
    items.remove(oldIndex);
    if (aItem.indexOfOrder(this) == -1)
    {
      wasRemoved = true;
    }
    else
    {
      wasRemoved = aItem.removeOrder(this);
      if (!wasRemoved)
      {
        items.add(oldIndex,aItem);
      }
    }
    return wasRemoved;
  }

  public boolean setItems(Item... newItems)
  {
    boolean wasSet = false;
    ArrayList<Item> verifiedItems = new ArrayList<Item>();
    for (Item aItem : newItems)
    {
      if (verifiedItems.contains(aItem))
      {
        continue;
      }
      verifiedItems.add(aItem);
    }

    if (verifiedItems.size() != newItems.length || verifiedItems.size() < minimumNumberOfItems())
    {
      return wasSet;
    }

    ArrayList<Item> oldItems = new ArrayList<Item>(items);
    items.clear();
    for (Item aNewItem : verifiedItems)
    {
      items.add(aNewItem);
      if (oldItems.contains(aNewItem))
      {
        oldItems.remove(aNewItem);
      }
      else
      {
        aNewItem.addOrder(this);
      }
    }

    for (Item anOldItem : oldItems)
    {
      anOldItem.removeOrder(this);
    }
    wasSet = true;
    return wasSet;
  }

  public boolean addItemAt(Item aItem, int index)
  {  
    boolean wasAdded = false;
    if(addItem(aItem))
    {
      if(index < 0 ) { index = 0; }
      if(index > numberOfItems()) { index = numberOfItems() - 1; }
      items.remove(aItem);
      items.add(index, aItem);
      wasAdded = true;
    }
    return wasAdded;
  }

  public boolean addOrMoveItemAt(Item aItem, int index)
  {
    boolean wasAdded = false;
    if(items.contains(aItem))
    {
      if(index < 0 ) { index = 0; }
      if(index > numberOfItems()) { index = numberOfItems() - 1; }
      items.remove(aItem);
      items.add(index, aItem);
      wasAdded = true;
    } 
    else 
    {
      wasAdded = addItemAt(aItem, index);
    }
    return wasAdded;
  }

  public boolean setBill(Bill aBill)
  {
    boolean wasSet = false;
    //Must provide bill to order
    if (aBill == null)
    {
      return wasSet;
    }

    if (bill != null && bill.numberOfOrders() <= Bill.minimumNumberOfOrders())
    {
      return wasSet;
    }

    Bill existingBill = bill;
    bill = aBill;
    if (existingBill != null && !existingBill.equals(aBill))
    {
      boolean didRemove = existingBill.removeOrder(this);
      if (!didRemove)
      {
        bill = existingBill;
        return wasSet;
      }
    }
    bill.addOrder(this);
    wasSet = true;
    return wasSet;
  }

  public void delete()
  {
    Waiter placeholderWaiter = waiter;
    this.waiter = null;
    placeholderWaiter.removeOrder(this);
    Customer existingCustomer = customer;
    customer = null;
    if (existingCustomer != null)
    {
      existingCustomer.delete();
    }
    ArrayList<Item> copyOfItems = new ArrayList<Item>(items);
    items.clear();
    for(Item aItem : copyOfItems)
    {
      aItem.removeOrder(this);
    }
    Bill placeholderBill = bill;
    this.bill = null;
    placeholderBill.removeOrder(this);
  }


  public String toString()
  {
	  String outputString = "";
    return super.toString() + "["+
            "orderNumber" + ":" + getOrderNumber()+ "]" + System.getProperties().getProperty("line.separator") +
            "  " + "waiter = "+(getWaiter()!=null?Integer.toHexString(System.identityHashCode(getWaiter())):"null") + System.getProperties().getProperty("line.separator") +
            "  " + "customer = "+(getCustomer()!=null?Integer.toHexString(System.identityHashCode(getCustomer())):"null") + System.getProperties().getProperty("line.separator") +
            "  " + "bill = "+(getBill()!=null?Integer.toHexString(System.identityHashCode(getBill())):"null")
     + outputString;
  }
}