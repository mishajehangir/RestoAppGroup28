package ca.mcgill.ecse223.resto.model;
/*PLEASE DO NOT EDIT THIS CODE*/
/*This code was generated using the UMPLE 1.20.1.4071 modeling language!*/


import java.util.*;

// line 11 "RestoAppDomailModel.ump"
public class Customer extends Role
{

  //------------------------
  // MEMBER VARIABLES
  //------------------------

  //Customer Associations
  private Seat seat;
  private Order order;

  //------------------------
  // CONSTRUCTOR
  //------------------------

  public Customer(Order aOrder)
  {
    super();
    if (aOrder == null || aOrder.getCustomer() != null)
    {
      throw new RuntimeException("Unable to create Customer due to aOrder");
    }
    order = aOrder;
  }

  public Customer(int aOrderNumberForOrder, Waiter aWaiterForOrder, Bill aBillForOrder, Item... allItemsForOrder)
  {
    super();
    order = new Order(aOrderNumberForOrder, aWaiterForOrder, this, aBillForOrder, allItemsForOrder);
  }

  //------------------------
  // INTERFACE
  //------------------------

  public Seat getSeat()
  {
    return seat;
  }

  public boolean hasSeat()
  {
    boolean has = seat != null;
    return has;
  }

  public Order getOrder()
  {
    return order;
  }

  public boolean setSeat(Seat aNewSeat)
  {
    boolean wasSet = false;
    if (seat != null && !seat.equals(aNewSeat) && equals(seat.getCustomer()))
    {
      //Unable to setSeat, as existing seat would become an orphan
      return wasSet;
    }

    seat = aNewSeat;
    Customer anOldCustomer = aNewSeat != null ? aNewSeat.getCustomer() : null;

    if (!this.equals(anOldCustomer))
    {
      if (anOldCustomer != null)
      {
        anOldCustomer.seat = null;
      }
      if (seat != null)
      {
        seat.setCustomer(this);
      }
    }
    wasSet = true;
    return wasSet;
  }

  public void delete()
  {
    Seat existingSeat = seat;
    seat = null;
    if (existingSeat != null)
    {
      existingSeat.delete();
    }
    Order existingOrder = order;
    order = null;
    if (existingOrder != null)
    {
      existingOrder.delete();
    }
    super.delete();
  }

}