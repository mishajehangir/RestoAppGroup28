package ca.mcgill.ecse223.resto.model;
/*PLEASE DO NOT EDIT THIS CODE*/
/*This code was generated using the UMPLE 1.20.1.4071 modeling language!*/


import java.sql.Date;
import java.sql.Time;

// line 24 "RestoAppDomailModel.ump"
public class Reservation
{

  //------------------------
  // MEMBER VARIABLES
  //------------------------

  //Reservation Attributes
  private Date date;
  private Time startingTime;
  private int numberOfSeat;
  private String customerName;
  private int phoneNumber;
  private String email;
  private int reservationNumber;

  //Reservation Associations
  private Waiter waiter;

  //------------------------
  // CONSTRUCTOR
  //------------------------

  public Reservation(Date aDate, Time aStartingTime, int aNumberOfSeat, String aCustomerName, int aPhoneNumber, String aEmail, int aReservationNumber, Waiter aWaiter)
  {
    date = aDate;
    startingTime = aStartingTime;
    numberOfSeat = aNumberOfSeat;
    customerName = aCustomerName;
    phoneNumber = aPhoneNumber;
    email = aEmail;
    reservationNumber = aReservationNumber;
    boolean didAddWaiter = setWaiter(aWaiter);
    if (!didAddWaiter)
    {
      throw new RuntimeException("Unable to create reservation due to waiter");
    }
  }

  //------------------------
  // INTERFACE
  //------------------------

  public boolean setDate(Date aDate)
  {
    boolean wasSet = false;
    date = aDate;
    wasSet = true;
    return wasSet;
  }

  public boolean setStartingTime(Time aStartingTime)
  {
    boolean wasSet = false;
    startingTime = aStartingTime;
    wasSet = true;
    return wasSet;
  }

  public boolean setNumberOfSeat(int aNumberOfSeat)
  {
    boolean wasSet = false;
    numberOfSeat = aNumberOfSeat;
    wasSet = true;
    return wasSet;
  }

  public boolean setCustomerName(String aCustomerName)
  {
    boolean wasSet = false;
    customerName = aCustomerName;
    wasSet = true;
    return wasSet;
  }

  public boolean setPhoneNumber(int aPhoneNumber)
  {
    boolean wasSet = false;
    phoneNumber = aPhoneNumber;
    wasSet = true;
    return wasSet;
  }

  public boolean setEmail(String aEmail)
  {
    boolean wasSet = false;
    email = aEmail;
    wasSet = true;
    return wasSet;
  }

  public boolean setReservationNumber(int aReservationNumber)
  {
    boolean wasSet = false;
    reservationNumber = aReservationNumber;
    wasSet = true;
    return wasSet;
  }

  public Date getDate()
  {
    return date;
  }

  public Time getStartingTime()
  {
    return startingTime;
  }

  public int getNumberOfSeat()
  {
    return numberOfSeat;
  }

  public String getCustomerName()
  {
    return customerName;
  }

  public int getPhoneNumber()
  {
    return phoneNumber;
  }

  public String getEmail()
  {
    return email;
  }

  public int getReservationNumber()
  {
    return reservationNumber;
  }

  public Waiter getWaiter()
  {
    return waiter;
  }

  public boolean setWaiter(Waiter aWaiter)
  {
    boolean wasSet = false;
    if (aWaiter == null)
    {
      return wasSet;
    }

    Waiter existingWaiter = waiter;
    waiter = aWaiter;
    if (existingWaiter != null && !existingWaiter.equals(aWaiter))
    {
      existingWaiter.removeReservation(this);
    }
    waiter.addReservation(this);
    wasSet = true;
    return wasSet;
  }

  public void delete()
  {
    Waiter placeholderWaiter = waiter;
    this.waiter = null;
    placeholderWaiter.removeReservation(this);
  }


  public String toString()
  {
	  String outputString = "";
    return super.toString() + "["+
            "numberOfSeat" + ":" + getNumberOfSeat()+ "," +
            "customerName" + ":" + getCustomerName()+ "," +
            "phoneNumber" + ":" + getPhoneNumber()+ "," +
            "email" + ":" + getEmail()+ "," +
            "reservationNumber" + ":" + getReservationNumber()+ "]" + System.getProperties().getProperty("line.separator") +
            "  " + "date" + "=" + (getDate() != null ? !getDate().equals(this)  ? getDate().toString().replaceAll("  ","    ") : "this" : "null") + System.getProperties().getProperty("line.separator") +
            "  " + "startingTime" + "=" + (getStartingTime() != null ? !getStartingTime().equals(this)  ? getStartingTime().toString().replaceAll("  ","    ") : "this" : "null") + System.getProperties().getProperty("line.separator") +
            "  " + "waiter = "+(getWaiter()!=null?Integer.toHexString(System.identityHashCode(getWaiter())):"null")
     + outputString;
  }  
  //------------------------
  // DEVELOPER CODE - PROVIDED AS-IS
  //------------------------
  
  // line 34 RestoAppDomailModel.ump
  0..1 -<@> 1..* Table ;

  
}