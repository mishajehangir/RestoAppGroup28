package ca.mcgill.ecse223.resto.model;
/*PLEASE DO NOT EDIT THIS CODE*/
/*This code was generated using the UMPLE 1.20.1.4071 modeling language!*/


import java.util.*;

// line 37 "RestoAppDomailModel.ump"
public class Table
{

  //------------------------
  // MEMBER VARIABLES
  //------------------------

  //Table Attributes
  private int tableNumber;
  private int numberOfSeat;
  private boolean available;
  private int numberOfOccupiedSeat;

  //Table Associations
  private List<Seat> seats;

  //------------------------
  // CONSTRUCTOR
  //------------------------

  public Table(int aTableNumber, int aNumberOfSeat, boolean aAvailable, int aNumberOfOccupiedSeat)
  {
    tableNumber = aTableNumber;
    numberOfSeat = aNumberOfSeat;
    available = aAvailable;
    numberOfOccupiedSeat = aNumberOfOccupiedSeat;
    seats = new ArrayList<Seat>();
  }

  //------------------------
  // INTERFACE
  //------------------------

  public boolean setTableNumber(int aTableNumber)
  {
    boolean wasSet = false;
    tableNumber = aTableNumber;
    wasSet = true;
    return wasSet;
  }

  public boolean setNumberOfSeat(int aNumberOfSeat)
  {
    boolean wasSet = false;
    numberOfSeat = aNumberOfSeat;
    wasSet = true;
    return wasSet;
  }

  public boolean setAvailable(boolean aAvailable)
  {
    boolean wasSet = false;
    available = aAvailable;
    wasSet = true;
    return wasSet;
  }

  public boolean setNumberOfOccupiedSeat(int aNumberOfOccupiedSeat)
  {
    boolean wasSet = false;
    numberOfOccupiedSeat = aNumberOfOccupiedSeat;
    wasSet = true;
    return wasSet;
  }

  public int getTableNumber()
  {
    return tableNumber;
  }

  public int getNumberOfSeat()
  {
    return numberOfSeat;
  }

  public boolean getAvailable()
  {
    return available;
  }

  public int getNumberOfOccupiedSeat()
  {
    return numberOfOccupiedSeat;
  }

  public Seat getSeat(int index)
  {
    Seat aSeat = seats.get(index);
    return aSeat;
  }

  public List<Seat> getSeats()
  {
    List<Seat> newSeats = Collections.unmodifiableList(seats);
    return newSeats;
  }

  public int numberOfSeats()
  {
    int number = seats.size();
    return number;
  }

  public boolean hasSeats()
  {
    boolean has = seats.size() > 0;
    return has;
  }

  public int indexOfSeat(Seat aSeat)
  {
    int index = seats.indexOf(aSeat);
    return index;
  }

  public boolean isNumberOfSeatsValid()
  {
    boolean isValid = numberOfSeats() >= minimumNumberOfSeats();
    return isValid;
  }

  public static int minimumNumberOfSeats()
  {
    return 1;
  }

  public Seat addSeat(int aSeatNumber, Customer aCustomer)
  {
    Seat aNewSeat = new Seat(aSeatNumber, this, aCustomer);
    return aNewSeat;
  }

  public boolean addSeat(Seat aSeat)
  {
    boolean wasAdded = false;
    if (seats.contains(aSeat)) { return false; }
    Table existingTable = aSeat.getTable();
    boolean isNewTable = existingTable != null && !this.equals(existingTable);

    if (isNewTable && existingTable.numberOfSeats() <= minimumNumberOfSeats())
    {
      return wasAdded;
    }

    if (isNewTable)
    {
      aSeat.setTable(this);
    }
    else
    {
      seats.add(aSeat);
    }
    wasAdded = true;
    return wasAdded;
  }

  public boolean removeSeat(Seat aSeat)
  {
    boolean wasRemoved = false;
    //Unable to remove aSeat, as it must always have a table
    if (this.equals(aSeat.getTable()))
    {
      return wasRemoved;
    }

    //table already at minimum (1)
    if (numberOfSeats() <= minimumNumberOfSeats())
    {
      return wasRemoved;
    }

    seats.remove(aSeat);
    wasRemoved = true;
    return wasRemoved;
  }

  public boolean addSeatAt(Seat aSeat, int index)
  {  
    boolean wasAdded = false;
    if(addSeat(aSeat))
    {
      if(index < 0 ) { index = 0; }
      if(index > numberOfSeats()) { index = numberOfSeats() - 1; }
      seats.remove(aSeat);
      seats.add(index, aSeat);
      wasAdded = true;
    }
    return wasAdded;
  }

  public boolean addOrMoveSeatAt(Seat aSeat, int index)
  {
    boolean wasAdded = false;
    if(seats.contains(aSeat))
    {
      if(index < 0 ) { index = 0; }
      if(index > numberOfSeats()) { index = numberOfSeats() - 1; }
      seats.remove(aSeat);
      seats.add(index, aSeat);
      wasAdded = true;
    } 
    else 
    {
      wasAdded = addSeatAt(aSeat, index);
    }
    return wasAdded;
  }

  public void delete()
  {
    for(int i=seats.size(); i > 0; i--)
    {
      Seat aSeat = seats.get(i - 1);
      aSeat.delete();
    }
  }


  public String toString()
  {
	  String outputString = "";
    return super.toString() + "["+
            "tableNumber" + ":" + getTableNumber()+ "," +
            "numberOfSeat" + ":" + getNumberOfSeat()+ "," +
            "available" + ":" + getAvailable()+ "," +
            "numberOfOccupiedSeat" + ":" + getNumberOfOccupiedSeat()+ "]"
     + outputString;
  }
}