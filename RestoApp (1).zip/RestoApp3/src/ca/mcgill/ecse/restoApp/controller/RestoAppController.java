package ca.mcgill.ecse.restoApp.controller;

import java.sql.Date;
import java.sql.Time;
import java.util.ArrayList;
import java.util.List;

import javax.swing.JOptionPane;

import ca.mcgill.ecse.restoApp.controller.InvalidInputException;
import ca.mcgill.ecse.restoApp.application.RestoAppApplication;
import ca.mcgill.ecse223.resto.model.MenuItem;
import ca.mcgill.ecse223.resto.model.Order;
import ca.mcgill.ecse223.resto.model.Reservation;
import ca.mcgill.ecse223.resto.model.RestoApp;
import ca.mcgill.ecse223.resto.model.Seat;
import ca.mcgill.ecse223.resto.model.Table;
import ca.mcgill.ecse223.resto.model.Table.Status;

public class RestoAppController
{
	public RestoAppController() 
	{
	}
	
	//method to create a table
	public static void createTable(int number, int x, int y,int width, int length, int numberOfSeats) throws InvalidInputException {
		if( x <0 || y<0 || width<20 || length<20 || numberOfSeats<1) {
			throw new InvalidInputException("The inputs are not valid");
		}
		RestoApp restoApp = RestoAppApplication.getRestoApp();
		List<Table> currentTables =  restoApp.getCurrentTables();
		for(Table currentTable: currentTables) {
			try 
			{
				if(doesOverlap(x, y, width, length,currentTable) == true)
				{
					throw new InvalidInputException("Overlap");
				}
			} catch (Exception e) 
			{
				throw new RuntimeException(e);
			}
		}
		Table table = new Table(number, x, y, width, length, restoApp);
		restoApp.addCurrentTable(table);
		for(int z=0; z<numberOfSeats;z++) {
			Seat seat = table.addSeat();
			table.addCurrentSeat(seat);
		}
		RestoAppApplication.save();
	}	
	
	//method to move a table
	public static void moveTable(Table table, int x, int y) throws InvalidInputException
	{
		if(table == null && x < 0 && y < 0)
		{
			throw new InvalidInputException("Invalid Input");
		}

		RestoApp r = table.getRestoApp();
		List<Table> tableList = r.getCurrentTables();	
		for(int i = 0; i < tableList.size(); i++)
		{
			Table curTable = tableList.get(i);
			
			if (curTable != table) 
			{		
				try 
				{
					if(doesOverlap(x, y, table.getWidth(), table.getLength(), curTable) == true)
					{
						throw new InvalidInputException("Overlap");
					}
				} catch (Exception e) 
				{
					System.out.println("overlap with table "+curTable.getNumber());
					return;
				}
			
			}
		}
		
		table.setX(x);
		table.setY(y);
		
	RestoAppApplication.save();
	}
	
	//method to remove a table
	public static void removeTable(Table table) throws InvalidInputException {
		//throw InvalidInputException if table is null
		if(table == null) {
			throw new InvalidInputException("No table was selected");
		}
		
		//throw InvalidInputException if 
		boolean reserved = table.hasReservations();
		if(reserved) {
			throw new InvalidInputException("Table has a reservation");
		}
		
		RestoApp r = RestoAppApplication.getRestoApp();
		
		//List<Order> currentOrders = r.getCurrentOrders();
		java.util.List<Order> currentOrders = r.getCurrentOrders();
		
		for(Order order : currentOrders) {
			java.util.List<Table> tables = order.getTables();
			boolean inUse = tables.contains(table);
			if(inUse) {
				throw new InvalidInputException("Table has an order");
			}
		}
		Integer tableNumber = table.getNumber();
		r.removeCurrentTable(table);
		System.out.println("I just removed table number " + tableNumber);
		RestoAppApplication.save();
		
	}
	
	//method to update a table
	public static void updateTable(Table table, int newNumber, int numberOfSeats) throws InvalidInputException
	{
		String error;
		if(table == null)
		{
			error = "There is no selected table.";
			throw new InvalidInputException(error);
		}
		if(newNumber <= 0)
		{
			error = "The seat index can't be zero or negative.";
			throw new InvalidInputException(error);
		}
		if(numberOfSeats <= 0)
		{
			error = "There can't be less than one seat";
			throw new InvalidInputException(error);
		}
		
		Boolean reserved = table.hasReservations();
		if(reserved ==true)
		{
			throw new InvalidInputException("This table has already been reserved.");
		}
		
		RestoApp r = RestoAppApplication.getRestoApp();
		
		List<Order> currentOrders = r.getCurrentOrders(); //have to change cast type
		
		for(int i = 0; i < currentOrders.size(); i++)
		{
			List<Table> tables = currentOrders.get(i).getTables();
			
			Boolean inUse = tables.contains(table);
			
			if(inUse == true)
			{
				throw new InvalidInputException("This table number is already in use");
			}
		}
		
		table.setNumber(newNumber);
		
		int n =table.numberOfCurrentSeats();
		
				
		for(int j = 1; j <= (numberOfSeats - n); j++)
		{
			Seat seat = table.addSeat();
			
			table.addCurrentSeat(seat);
		}
		
		for(int k = 1; k <= (n-numberOfSeats); k++)
		{
			Seat seat = table.getCurrentSeat(0);
			
			table.removeCurrentSeat(seat);
			
		}
		
		RestoAppApplication.save();
		
	}
	
	//create the menu
	public static ArrayList<MenuItem> getMenuItems(MenuItem.ItemCategory itemCategory){
		   
	   List<MenuItem> completeList = new ArrayList<MenuItem>();
	   RestoApp restoApp = RestoAppApplication.getRestoApp();
	   ca.mcgill.ecse223.resto.model.Menu menu = restoApp.getMenu();
	   
	   ArrayList<MenuItem> categoryList = new ArrayList<MenuItem>();
	   
	   completeList = menu.getMenuItems();
	   
	   for (MenuItem item : completeList) {
	     boolean current = item.hasCurrentPricedMenuItem();
	     MenuItem.ItemCategory myItemCategory = item.getItemCategory();
	     if (current && myItemCategory.equals(itemCategory)){
	       categoryList.add(item);
	     }
	   }
	  return categoryList;	   
	}
	
	//method to start an order
	public static void startOrder(List<Table> tables) throws InvalidInputException {
		try {
			if(tables == null) 
			{
				throw new InvalidInputException("The list of tables is null");

			}
		} catch (Exception e1) {
			System.out.println("The list of tables is null");
		}
		
		RestoApp r = RestoAppApplication.getRestoApp();
		
		List<Table> currentTables = r.getCurrentTables();
		
		boolean current = true;
		for(Table table : tables) 
		{
			current = currentTables.contains(table);
		}
		try {
			if(current == false)
			{
				throw new InvalidInputException("There is a table that is not part of currentTables");
			}
		} catch (Exception e) {
			System.out.println("There is a table that is not part of currentTables");
		}

		boolean orderCreated = false;
		Order newOrder = null;
		Order lastOrder;
		for(Table table: tables)
		{
			if(orderCreated)
			{
				table.addToOrder(newOrder);
			}
			else
			{
				lastOrder = null;
				if(table.numberOfOrders()>0)
				{
					lastOrder = table.getOrder(table.numberOfOrders()-1);
				}
				
				table.startOrder();
	
				if(table.numberOfOrders()>0 && !table.getOrder(table.numberOfOrders()-1).equals(lastOrder))
				{
					orderCreated = true;
					newOrder = table.getOrder(table.numberOfOrders()-1);
				}
			}	
		}
		
		try {
			if(orderCreated == false)
			{
				throw new InvalidInputException("No order was created");
			}
		} catch (Exception e) {
			System.out.println("No order was created");
		}	
		r.addCurrentOrder(newOrder);
		RestoAppApplication.save();
	}
	
	//method to end an order
	public static void endOrder(Order order)throws InvalidInputException
	{
		//throw InvalidInputException if order is null
		try {
			if(order == null) 
			{
				throw new InvalidInputException("Order is empty");
			}
		} catch (Exception e) {
			System.out.println();
		}
		
		RestoApp r = RestoAppApplication.getRestoApp();
		
		List<Order> currentOrders = r.getCurrentOrders();
		
		Boolean current = currentOrders.contains(order);
		
		try {
			if(current == false) 
			{
				throw new InvalidInputException("");
			}
		} catch (Exception e) {
			System.out.println("");
			return;
		}
		
		List<Table> tables = order.getTables();
		
		for(int i = 0; i<tables.size();i++)
		{	
			if (tables.get(i).numberOfOrders() > 0 && tables.get(i).getOrder(tables.get(i).numberOfOrders()-1).equals(order)) 
			{
				tables.get(i).endOrder(order);
				break;
			}
		}
		
		
		if(allTablesAvailibleOrDifferentCurrentOrder(tables,order) == true)
		{
			r.removeCurrentOrder(order);
		}
			
		
		RestoAppApplication.save();
		
	}
	
	public static Boolean allTablesAvailibleOrDifferentCurrentOrder(List<Table> tables, Order order)//verify
	{
		Boolean x;
		x = false;
		
		for(Table table:tables)
		{
			if(table.getStatus() == Status.Available || table.getOrders() != order)
			{
				x = true;
			}
			else
			{
				x = false;
				break;
			}
		}
		return x;
	}
	
	public static void createReservation(Date date, Time time, int numberInParty, String contactName, String contactEmailAddress, String contactPhoneNumber, List<Table> tables) throws InvalidInputException
    {
        RestoApp restoApp = RestoAppApplication.getRestoApp();
        List<Table> currentTables = restoApp.getCurrentTables();
        int seatCapacity = 0;
        
        for(int i = 0; i < tables.size(); i++)
        {
            Table table = tables.get(i);
            
            boolean current = currentTables.contains(table);
            
            
            try {
                if(current == false)
                {
                    throw new InvalidInputException("is not contained");
                }
            } catch (Exception e) {
              JOptionPane.showMessageDialog(null, "is not contained");
              return;
            }
            
            seatCapacity +=  table.numberOfCurrentSeats();
            try {
              if(seatCapacity < numberInParty)
              {
                  throw new InvalidInputException("There is not enough space for everybody at those tables");
              }
	            } catch (Exception e) {
	              JOptionPane.showMessageDialog(null, "There is not enough space for everybody at those tables");
	              return;
	              
	            }
             
            List<Reservation> reservations = table.getReservations();
            
            boolean overlaps = false;
            for(Reservation reservation : reservations)
            {
                overlaps = reservation.doesOverlap(date, time);
                try {
                    if(overlaps == true)
                    {
                        throw new InvalidInputException("A reservation already exists during that time");
                    }
                } catch (Exception e) {
                  JOptionPane.showMessageDialog(null, "A reservation already exists during that time");
                    return;
                }

            }
        }
        
        Table[] tableArray = new Table[tables.size()];
        int i=0;
        for(Table table: tables) 
        {
            tableArray[i] = table;
            i++;
        }
  
        RestoApp r = RestoAppApplication.getRestoApp();
        Reservation res = new Reservation(date, time, numberInParty, contactName, contactEmailAddress, contactPhoneNumber, r, tableArray);
        JOptionPane.showMessageDialog(null, "Reservation Number: " + res.getReservationNumber());
        RestoAppApplication.save();
        return;
    }
    
   
	
	public static boolean doesOverlap(int x, int y, int width, int length, Table aTable) throws InvalidInputException
	  {
		  
		  int topLeftX = aTable.getX() - 15;
		  int topLeftY = aTable.getY() -15;
		  
		  int bottomrRightX = aTable.getX() + aTable.getWidth() + 15;
		  int bottomrRightY = aTable.getY() + aTable.getLength() + 15;
				  
		  //one rectangle is on the left of the other one
		  if(x -15 >= bottomrRightX || topLeftX >= (x + width + 15))
			  return false;
		  
		  //one rectangle is above the other one
		  if(bottomrRightY <= y - 15 || y + length + 15 <= topLeftY)
			  return false;
	  
		  return true;
	  }
}	
