/*PLEASE DO NOT EDIT THIS CODE*/
/*This code was generated using the UMPLE 1.27.0.3728.d139ed893 modeling language!*/

package ca.mcgill.ecse223.resto.model;
import java.io.Serializable;

// line 104 "../../../../../RestoAppPersistence.ump"
// line 77 "../../../../../RestoApp v3.ump"
public class Rating implements Serializable
{

  //------------------------
  // MEMBER VARIABLES
  //------------------------

  //Rating Attributes
  private int rating;

  //Rating Associations
  private MenuItem menuItem;
  private RestoApp restoApp;

  //------------------------
  // CONSTRUCTOR
  //------------------------

  public Rating(int aRating, MenuItem aMenuItem, RestoApp aRestoApp)
  {
    rating = aRating;
    if (!setMenuItem(aMenuItem))
    {
      throw new RuntimeException("Unable to create Rating due to aMenuItem");
    }
    boolean didAddRestoApp = setRestoApp(aRestoApp);
    if (!didAddRestoApp)
    {
      throw new RuntimeException("Unable to create rating due to restoApp");
    }
  }

  //------------------------
  // INTERFACE
  //------------------------

  public boolean setRating(int aRating)
  {
    boolean wasSet = false;
    rating = aRating;
    wasSet = true;
    return wasSet;
  }

  public int getRating()
  {
    return rating;
  }

  public MenuItem getMenuItem()
  {
    return menuItem;
  }

  public RestoApp getRestoApp()
  {
    return restoApp;
  }

  public boolean setMenuItem(MenuItem aNewMenuItem)
  {
    boolean wasSet = false;
    if (aNewMenuItem != null)
    {
      menuItem = aNewMenuItem;
      wasSet = true;
    }
    return wasSet;
  }

  public boolean setRestoApp(RestoApp aRestoApp)
  {
    boolean wasSet = false;
    if (aRestoApp == null)
    {
      return wasSet;
    }

    RestoApp existingRestoApp = restoApp;
    restoApp = aRestoApp;
    if (existingRestoApp != null && !existingRestoApp.equals(aRestoApp))
    {
      existingRestoApp.removeRating(this);
    }
    restoApp.addRating(this);
    wasSet = true;
    return wasSet;
  }

  public void delete()
  {
    menuItem = null;
    RestoApp placeholderRestoApp = restoApp;
    this.restoApp = null;
    if(placeholderRestoApp != null)
    {
      placeholderRestoApp.removeRating(this);
    }
  }


  public String toString()
  {
    return super.toString() + "["+
            "rating" + ":" + getRating()+ "]" + System.getProperties().getProperty("line.separator") +
            "  " + "menuItem = "+(getMenuItem()!=null?Integer.toHexString(System.identityHashCode(getMenuItem())):"null") + System.getProperties().getProperty("line.separator") +
            "  " + "restoApp = "+(getRestoApp()!=null?Integer.toHexString(System.identityHashCode(getRestoApp())):"null");
  }  
  //------------------------
  // DEVELOPER CODE - PROVIDED AS-IS
  //------------------------
  
  // line 107 "../../../../../RestoAppPersistence.ump"
  private static final long serialVersionUID = -2547777835946368626L ;

  
}